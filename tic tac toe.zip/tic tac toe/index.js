const cells = document.querySelectorAll('.cell');
const statusText = document.getElementById('status');
let currentPlayer = 'X';
let gameBoard = ['', '', '', '', '', '', '', '', ''];
let isGameActive = true;

const winningCombination = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

function checkWinner() {
  for (let combination of winningCombination) {
    const [a, b, c] = combination;
    if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
      setTimeout(() => {
        statusText.textContent = `${currentPlayer} Wins!`;
        statusText.style.color = currentPlayer === 'X' ? '#4CAF50' : '#FF5733';
      }, 100);
      isGameActive = false;
      return;
    }
  }
  
  if (!gameBoard.includes('')) {
    setTimeout(() => {
      statusText.textContent = "It's a Draw!";
      statusText.style.color = '#FF9800';
    }, 100);
    isGameActive = false;
  }
}

function handleCellClick(event) {
  const cellIndex = event.target.id.split('-')[1];
  
  if (gameBoard[cellIndex] !== '' || !isGameActive) return;
  
  gameBoard[cellIndex] = currentPlayer;
  event.target.textContent = currentPlayer;

  // Check for winner after the current player makes a move
  checkWinner();
  
  // Switch the player only if the game is still active
  if (isGameActive) {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    statusText.textContent = `Player ${currentPlayer}'s turn`;
  }
}

function restartGame() {
  gameBoard = ['', '', '', '', '', '', '', '', ''];
  isGameActive = true;
  currentPlayer = 'X';
  cells.forEach(cell => cell.textContent = '');
  statusText.textContent = `Player ${currentPlayer}'s turn`;
  statusText.style.color = '#333'; // Default text color
}

cells.forEach(cell => cell.addEventListener('click', handleCellClick));
document.getElementById('restart-btn').addEventListener('click', restartGame);
